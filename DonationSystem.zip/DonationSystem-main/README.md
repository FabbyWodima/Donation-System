# DonationSystem

# PLP-project


## Description
This is repo for my PLP project 
I tackled a solution to build a tech community where newbies can get mentors and help.

## Installation
```
git clone https://github.com/Username/DonationSystem.git
```

```
cd DonationSystem
```
### Create a virtual environment  and acticate environment

#### linux
```
 python3 -m venv env

source env/bin/activate
```
#### windows
```
 python -m venv env

.\env\Scripts\activate

```

### Install requirements
```
pip install -r requirements.txt
```
make migrations
```
python manage.py makemigrations
python manage.py migrate
```
### Run server
```
python manage.py runserver
```




